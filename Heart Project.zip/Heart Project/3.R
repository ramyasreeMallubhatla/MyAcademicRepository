install.packages("dplyr")
library(dplyr)
select(, ends_with("color"))
install.packages("dplyr")
library(dplyr)
faithful

select(faithful,eruptions)
filter(faithful,eruptions>=4.5)
faithful %>% 
  arrange(desc(waiting))

faithful %>%
  group_by(waiting) %>%
  summarise(
    
    eruptions = mean(eruptions, na.rm = TRUE)
  ) %>%
  filter(eruptions > 4.5)
